#include <stdio.h>

int main () {
    puts("main");
    return 0;
}

int func1() {
    int a = 0;

    if (a == 1) {
        return 0;
    } else {
        return 0;
    }
}

int func2()
{
    return 0;
}

int
func3() {
    return 0;
}

int
func4(int x,
      int y)
{
    return x + y;
}
