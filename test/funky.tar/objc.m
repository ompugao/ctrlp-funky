// objc
#import <stdoi.h>

@interface IFace : NSObject {
  int f1;
}

- (void) method1 {
}

+ (NSString *) method2 {
}
@end
