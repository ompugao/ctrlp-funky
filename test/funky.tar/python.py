class Vim:
    def editor():
        print "Vi Improved"

class CtrlP:
    def method():
        print "ctrlp!"


class Funky(Vim, CtrlP):
    def funk():
        print "funk"

    def saturday(night, fever):
        print "dancing"

    def sleeping(on,
                 sunday):
        print "zzZ"

    def monday(
            ):
        print "absent"

